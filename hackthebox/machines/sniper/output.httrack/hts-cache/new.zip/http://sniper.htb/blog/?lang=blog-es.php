<html>
<body>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Services blog</title>
  
  
  
      <link rel="stylesheet" href="/blog/css/style.css">

  
</head>

<body>

  
<div id="main">
  <div class="container">
    <nav>
      <div class="nav-fostrap">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="javascript:void(0)" >Language<span class="arrow-down"></span></a>
            <ul class="dropdown">
              <li><a href="/blog?lang=blog-en.php">English</a></li>
	      <li><a href="/blog?lang=blog-es.php">Spanish</a></li>
              <li><a href="/blog?lang=blog-fr.php">French</a></li>
            </ul>
          </li>
          <li><a href="javascript:void(0)" >Download<span class="arrow-down"></span></a>
            <ul class="dropdown">
              <li><a href="">Tools</a></li>
              <li><a href="">Backlink</a></li>
            </ul>
          </li>
        </ul>
      </div>
      <div class="nav-bg-fostrap">
        <div class="navbar-fostrap"> <span></span> <span></span> <span></span> </div>
        <a href="" class="title-mobile">Fostrap</a>
      </div>
    </nav>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
  
  

    <script  src="js/index.js"></script>




</body>

</html>
﻿<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>About us</title>
  <meta name="viewport" content="width=device-width">
<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Fira+Sans:300,400,500,700' rel='stylesheet' type='text/css'>
<script src="//use.typekit.net/tit4ltq.js"></script>
<script>try{Typekit.load();}catch(e){}</script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <style>
      /* NOTE: The styles were added inline because Prefixfree needs access to your styles and they must be inlined if they are on local disk! */
      body {
  color: #393f57;
  font-size:120%;
}

h1 {
  color: #00ab91;
  line-height:1.1;
}

h2 {
  line-height:1.1;
}

p {
  line-height:1.4;
}

header .bars {
	display: block;
	height: 5px;
	margin: 0;
	overflow: hidden;
	position: fixed;
	text-align: center;
	top: 0;
	width: 100%;
}
header .bars ul {
	margin: 0;
	padding: 0;
}
header .bars ul li {
	display: block;
	float: left;
	height: 5px;
	overflow: hidden;
	width: 20%;
}
header .bars .cor-1 {
	background: #ED5565;
}
header .bars .cor-2 {
	background: #f59120;
}
header .bars .cor-3 {
	background: #FCBB42;
}
header .bars .cor-4 {
	background: #94c23d;
}
header .bars .cor-5 {
	background-color: #3498db;
}

header .header-title {
  background: #00ab91;
  height: 200px;
  color: #efefef;
  line-height: 200px;
  text-align: center;
  font-size: 28px;
  font-weight:bold;
}

section {
  margin:0 auto;
  padding-top:2.5%;
  padding-bottom:2.5%;
  max-width:600px;
}

section:first-child:last-child {
  padding-top:5%;
  padding-bottom:5%;
}

section.content-block {
  font-family:'proxima-nova-soft';
}
section.content-block p {
  font-weight:500;
}

footer {
  right: 0;
  bottom: 0;
  left: 0;
  padding: 1rem;
  background-color: #efefef;
  text-align: center;
}

@media screen and (max-width: 960px) {
	header .bars {
		position: inherit;
	}
}
    </style>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>

</head>

<body>

  <header>
  <div class="bars">
    <ul>
      <li class="cor-1"></li>
      <li class="cor-2"></li>
      <li class="cor-3"></li>
      <li class="cor-4"></li>
      <li class="cor-5"></li>
    </ul>
  </div>
  <div class="header-title">
    About us
  </div>
</header>
<section class="content-block">
  <h1>Lorem ipsum dolor sit amet</h1>
  <h2>Lorem ipsum?</h2>
  <p>

<p>Ya sea que se trate de 10 violines para una tienda de música local o 10,000 vacunas para una clínica en el extranjero, hay mucho en juego en su capacidad de entregar y rastrear un paquete. Pero la información que necesita sobre el estado para administrar estos dos envíos es completamente diferente. Ofrecemos servicios para rastrear a la persona responsable de la entrega y mantener notas al respecto.</p>

<p>Es por eso que hemos desarrollado una gama de herramientas de seguimiento que brindan precisamente la información que necesita, dónde y cuándo la necesita. Así que puedes reencaminar esos violines para llegar a la escuela el primer día de clases. O bien, calcule la entrega de ese medicamento que salva vidas para que la clínica pueda programar al personal.
</p>




</section>

<section class="content-block">
  <h1>Lorem ipsum dolor sit amet</h1>
  <h2>Lorem ipsum?</h2>
  <p>Lorem ipsum dolor sit amet, consectetur adip*isicing elit, sed do eiusmod *tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adip*isicing elit, sed do eiusmod *tempor incididunt ut labore et dolore magna aliqua.</p>
  <p>Lorcontent-blockem ipsum dolor sit amet, consectetur adip*isicing elit, sed do eiusmod *tempor incididunt ut labore et dolore magna aliqua.</p>
</section>

<section class="content-block">
  <h1>Lorem ipsum dolor sit amet</h1>
  <h2>Lorem ipsum?</h2>
  <p>Lorem ipsum dolor sit amet, consectetur adip*isicing elit, sed do eiusmod *tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adip*isicing elit, sed do eiusmod *tempor incididunt ut labore et dolore magna aliqua.</p>
  <p>Lorem ipsum dolor sit amet, consectetur adip*isicing elit, sed do eiusmod *tempor incididunt ut labore et dolore magna aliqua.</p>
</section>

<footer>
  <strong>Sniper Co. 2019</strong>
</footer>
  
  

</body>

</html>
</body>
</html>	

